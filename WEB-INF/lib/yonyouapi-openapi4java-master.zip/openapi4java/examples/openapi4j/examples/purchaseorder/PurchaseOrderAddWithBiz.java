package openapi4j.examples.purchaseorder;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;

import openapi4j.exception.OpenAPIException;
import openapi4j.service.PurchaseOrderService;

/**
 * Copyright(c) 2015-2015 by yonyouup. All Rights Reserved 采购订单
 * 
 * @author yanwuyang
 * @version <类版本> , 2015年12月9日
 * @see <相关类/方法>
 * @since <产品/模块版本>
 */
public class PurchaseOrderAddWithBiz {

    final static Logger logger = LogManager.getLogger(PurchaseOrderAddWithBiz.class);

    public static void main(String[] args) {
        String to_account = args[0];//提供方id
        String jsonBody = args[1];//请求body体数据
        String bizId = args[2];//采购订单号
        PurchaseOrderService purchaseOrderService = new PurchaseOrderService();
        try {
            JSONObject record = purchaseOrderService.addByBizId(bizId, jsonBody, to_account);
            logger.info(record.toString());
        } catch (OpenAPIException e) {
            e.printStackTrace();
        }
    }

}
